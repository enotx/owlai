# -*- coding: utf8 -*-

from setuptools import setup, find_packages

VERSION = (0, 2, 3, 'final')
__version__ = VERSION


def get_version():
    version = '{0}.{1}'.format(VERSION[0], VERSION[1])
    if VERSION[2]:
        version = '{0}.{1}'.format(version, VERSION[2])
    if VERSION[3:] == ('alpha', 0):
        version = '{0} pre-alpha'.format(version)
    else:
        if VERSION[3] != 'final':
            version = '{0} {1}'.format(version, VERSION[3])
    return version


setup(
        name="pytalos",
        version=get_version(),
        include_package_data=True,
        description='Talos Python SDK',
        url='http://git.sankuai.com/scm/data/talos-sdk.git',
        author='wubiao02',
        author_email='wubiao02@meituan.com',
        packages=find_packages(),
        package_data={
            # If any package contains *.txt or *.rst files, include them:
            '': ['*.txt', '*.rst', '*.md', "*.yml", "*.yaml", "*.json"]
        }
)
