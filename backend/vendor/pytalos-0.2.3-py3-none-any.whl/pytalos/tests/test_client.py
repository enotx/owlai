# -*- coding:utf-8 -*-

import time
import logging
import unittest
from pprint import pprint

from pytalos import Talos, AsyncTalosClient, TalosException
from pytalos.tests import username, password, endpoint

logger = logging.getLogger(__name__)


class TalosTestCase(unittest.TestCase):

    def setUp(self):
        self.client = Talos(username, password, endpoint)
        self.client.open_session()

    def test_login(self):
        self.client._login()

    def test_submit(self):
        pass

    def test_download(self):
        for line in self.client.download("120788a259db11e997796c92bf274d3b"):
            print(line)

    def tearDown(self):
        # self.client.close_session()
        pass

    def test_fetch_all(self):
        print(self.client.fetch_all("120788a259db11e997796c92bf274d3b"))

    def test_fetch_many(self):
        print(self.client.fetch_many("120788a259db11e997796c92bf274d3b", 1))

    def test_fetch_one(self):
        print(self.client.fetch_one("120788a259db11e997796c92bf274d3b"))

    def test_fetch_result(self):
        print(self.client.fetch_result("120788a259db11e997796c92bf274d3b", 0, 1))

    def test_engine_log(self):
        print(self.client.engine_log("120788a259db11e997796c92bf274d3b"))

class AsyncTalosClientTestCase(TalosTestCase):
    def setUp(self):
        self.client = AsyncTalosClient(username, password, endpoint)
        self.client.open_session()

    def test_statement_too_long(self):
        data = {'dsn': 'hdim',
                "statement": 'a' * 1000001,
                'doas': '63442',
                'audit': '63442',
                'use_cache': True,
                'cache_expire': 3600,
                'engine': 'hive'}
        with self.assertRaises(TalosException) as context:
            self.client.submit(**data)
        self.assertEqual(str(context.exception), "statement can not be longer than 1000000.")

    def test_submit_hive(self):
        data = {'dsn': 'hdim',
                "statement": "select cityid as p1 from dim.city limit 30",
                'doas': '63442',
                'audit': '63442',
                'use_cache': True,
                'cache_expire': 3600,
                'engine': 'hive'}

        qid = self.client.submit(**data)
        print(qid)

    def test_submit_presto(self, limit=1):
        data = {'dsn': 'dim',
                'statement': 'select * from dim.city limit 10',
                'doas': '63442',
                'audit': '63442',
                'use_cache': True,
                'cache_expire': 3600,
                'engine': 'presto'}

        qid = self.client.submit(**data)
        print(qid)

    def test_batch_submit_mysql(self):
        for limit in range(1000, 2000, 5):
            self.test_submit_mysql(limit)

    def test_get_query_info(self):
        qid = '4d231328f9504e34953f86d937217cbe'
        query_info = self.client.get_query_info(qid)
        pprint(query_info)

    def test_fetch_result(self):
        qid = 'd5a94d092ce84bea83c2c15c569e5c00'
        result = self.client.fetch_result(qid, 0, 10)
        pprint(result)

    def test_cancel(self):
        qid = "4d231328f9504e34953f86d937217cbe"
        self.client.cancel(qid)


if __name__ == '__main__':
    unittest.main()
