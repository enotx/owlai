# -*- coding:utf-8 -*-

import unittest
import pytalos

from pytalos.tests import username, password


class DBITestCase(unittest.TestCase):
    def test_connect(self):
        conn = pytalos.connect(username, password, database="hive_dsn_test")
        cursor = conn.cursor()
        cursor.execute()
        self.assertEqual(True, False)


if __name__ == '__main__':
    unittest.main()
