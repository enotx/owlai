#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
from pytalos.client import AsyncTalosClient

def talos_query_demo():
    """Talos查询完整示例"""
    
    # 1. 配置参数
    username = "it_talos_qa_platform"  # 替换为你的用户名，格式：talos_xxxx_xxx
    password = "NFDAjklvxid_8382"  # 替换为你的密码
    endpoint = "http://10.133.6.5:8080"  # 推荐使用https域名
    
    # 2. 初始化客户端，设置request_timeout为0.05秒
    client = AsyncTalosClient(
        username=username, 
        password=password,
        endpoint=endpoint
    )
    
    try:
        # 3. 开启session（必须步骤）
        print("正在开启session...")
        session_opened = client.open_session()
        # if not session_opened:
        #     print("开启session失败")
        #     return
        # print("session开启成功")
        
        # 4. 提交查询
        engine = "presto"  # 可选：hive, presto
        sql = """select 
            *
            from log.data_talos2_query_submit
            WHERE dt = 20250915
            """
        
        print(f"提交查询: {sql}")
        print(f"使用引擎: {engine}")
        
        qid = client.submit(
            statement=sql, 
            engine=engine,
            doas='talos', 
            audit='gaorunshi',
            timeout=2
        )
        
        print(f"查询提交成功，qid: {qid}")
        
        # 5. 轮询查询状态
        print("等待查询完成...")
        finish = False
        max_wait_time = 300  # 最大等待5分钟
        start_time = time.time()
        
        while True:
            # 检查超时
            if time.time() - start_time > max_wait_time:
                print("查询超时，尝试取消...")
                try:
                    client.cancel(qid)  # cancel方法会使用client的request_timeout=0.05秒
                except Exception as e:
                    print(f"取消查询失败: {e}")
                break
            
            # 获取查询信息
            try:
                query_info = client.get_query_info(qid)  # 会使用client的request_timeout=0.05秒
                status = query_info["status"]
                print(f"查询状态: {status}")
                
                if status == "FINISHED":
                    finish = True
                    print("查询完成！")
                    print(f"结果总数: {query_info.get('total', 'N/A')}")
                    print(f"结果大小: {query_info.get('resultSize', 'N/A')} bytes")
                    break
                elif status in ["QUERY_TIMEOUT", "FAILED", "KILLED"] or status.startswith("ERROR_"):
                    finish = False
                    print(f"查询失败，状态: {status}")
                    if query_info.get("message"):
                        print(f"错误信息: {query_info['message']}")
                    break
                elif status in ["PENDING", "RUNNING"]:
                    # 打印引擎日志（可选）
                    try:
                        engine_log = client.engine_log(qid)  # 会使用client的request_timeout=1秒
                        if engine_log:
                            print("引擎日志:")
                            print(engine_log[-500:])  # 只打印最后500字符
                    except Exception as e:
                        print(f"获取引擎日志失败: {e}")
                    
                    time.sleep(5)  # 等待5秒后再次检查
                else:
                    print(f"未知状态: {status}")
                    time.sleep(5)
            except Exception as e:
                print(f"获取查询信息失败: {e}")
                time.sleep(5)
        
        # 6. 获取查询结果
        if finish:
            print("\n开始获取查询结果...")
            
            # 方法1: 使用fetch_result分页获取
            # print("=== 方法1: 分页获取前10行 ===")
            # try:
            #     result = client.fetch_result(qid, offset=0, length=10, timeout=2)  # 会使用client的request_timeout=0.05秒
            #     data = result["data"]
            #     columns = result.get("columns", [])
                
            #     # 打印列名
            #     if columns:
            #         column_names = [col["name"] for col in columns]
            #         print("列名: " + "\t".join(column_names))
                
            #     # 打印数据
            #     for i, row in enumerate(data):
            #         print(f"第{i+1}行: " + "\t".join(str(cell) for cell in row))
                    
            # except Exception as e:
            #     print(f"fetch_result失败: {e}")
             # 方法2: 使用download获取全量数据（推荐大数据量）
            print("\n=== 方法2: 流式下载全量数据 ===")
            try:
                row_count = 0
                for row in client.download(qid):  # download方法内部会使用固定的300秒timeout
                    row_count += 1
                    if row_count <= 5:  # 只打印前5行
                        print(f"第{row_count}行: " + "\t".join(str(cell) for cell in row))
                    elif row_count == 6:
                        print("...")
                
                print(f"总共下载了 {row_count} 行数据")
                
            except Exception as e:
                print(f"download失败: {e}")
            
        
    except Exception as e:
        print(f"发生异常: {e}")
        
    finally:
        # 7. 关闭session（重要）
        try:
            client.close_session()  # close_session内部可能没有网络请求，或者会使用client的request_timeout
            print("\nsession已关闭")
        except Exception as e:
            print(f"关闭session失败: {e}")


if __name__ == "__main__":
    talos_query_demo()
    