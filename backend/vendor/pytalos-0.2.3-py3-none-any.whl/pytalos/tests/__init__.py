# -*- coding:utf-8 -*-

import os

try:
    from configparser import ConfigParser
except ImportError:
    from ConfigParser import ConfigParser  # ver. < 3.0

# instantiate
config = ConfigParser()
ini_file = os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + "/settings.ini"
if not os.path.exists(ini_file):
    ini_file = os.getenv("TALOS_UNITTEST_INI")
    if ini_file is None:
        raise Exception("environment TALOS_UNITTEST_INI does not set, please set a file "
                        "which content look like:"
                        "[test]\n"
                        "endpoint = http://talos.data.sankuai.com\n"
                        "username = ***\n"
                        "password = ***")
config.read(ini_file)
# read values from a section
section = 'test'
username = config.get(section, 'username')
password = config.get(section, 'password')
endpoint = config.get(section, 'endpoint')
