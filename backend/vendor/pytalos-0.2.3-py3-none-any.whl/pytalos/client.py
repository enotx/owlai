# -*- coding:utf-8 -*-

import sys
import logging
import requests

try:
    import simplejson as json
except ImportError:
    import json
from functools import wraps

from enum import Enum

from pytalos.exceptions import *

logger = logging.getLogger(__name__)

TALOS_MODE = "prod"

if TALOS_MODE == "test":
    ENDPOINT = "http://talostwo.data.test.sankuai.com:8080"
else:
    ENDPOINT = "https://talostwo.vip.sankuai.com"


class SDKScene(Enum):
    SYSTEM_ACCOUNT = "SYSTEM_ACCOUNT"
    APPKEY = "APPKEY"
    MIS = "MIS"


def need_login(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if len(args) > 0 and isinstance(args[0], Talos):
            talos = args[0]
            if talos.username and talos.token:
                logger.debug("{0} has logon with token {1}.".format(talos.username, talos.token))
                return func(*args, **kwargs)
            elif talos.username and talos.password:
                try:
                    talos.open_session()
                except Exception as why:
                    logger.error("{0} logins fail because {1}. try again please.".format(talos.username, why.message))
                    logger.exception(why.message)
            else:
                logger.error("username or password is null, please login first.")
                raise TalosException("username or password is null, please login first.")

    return wrapper


def renew_token(exceptions=(Exception,)):
    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            try:
                return func(self, *args, **kwargs)
            except exceptions as e:
                if str(e).find("token has expired") >= 0:
                    logger.warning("{0} token expired, renew token".format(func.__name__))
                    self.open_session()
                    return func(self, *args, **kwargs)
                else:
                    raise e
        return wrapper
    return decorator


def is_successful(res):
    return res.status_code >= 200 and res.status_code < 300


def raise_exception(res):
    res.raise_for_status()
    if not is_successful(res):
        raise TalosException(res.content)
    ret = None
    try:
        ret = res.json()
    except:
        pass
    if ret:
        if int(ret.get("code")) != 1:
            raise TalosException(ret.get("message"))

def raise_exception_for_download(res):
    res.raise_for_status()
    if not is_successful(res):
        raise TalosException(res.content)

class Talos(object):
    def __init__(self, username, password, endpoint=ENDPOINT, properties=None, sdk_scene=SDKScene.SYSTEM_ACCOUNT):
        self.sdk_scene = sdk_scene
        self.endpoint = endpoint.rstrip("/")
        self.username = username
        self.password = password
        self.properties = properties

    def _login(self, timeout=20):
        login_api = "{0}/api/login".format(self.endpoint)
        params = {"username": self.username, "password": self.password, "sdkScene": self.sdk_scene.name}
        res = requests.post(login_api, data=params, timeout=timeout)

        raise_exception(res)

        self.token = res.json()['data']
        logger.info("{0} login success, token returned is {1}".format(self.username, self.token))

    @need_login
    def _logout(self, timeout=20):
        logger.info("{0} logout success".format(self.username))

    @need_login
    @renew_token(exceptions=(TalosException,))
    def _submit(self, dsn, statement, doas, audit, engine="onesql", use_cache=True, cache_expire=3600, debug=False,
                sync=False, timeout=20, properties=None):
        MAX_STATEMENT_LENGTH = 1000000
        if len(statement) > MAX_STATEMENT_LENGTH:
            msg = "statement can not be longer than {0}.".format(MAX_STATEMENT_LENGTH)
            logger.warning(msg)
            raise TalosException(msg)
        api = "{0}/api/v1/queries".format(self.endpoint)
        if doas is None:
            doas = self.username
        if audit is None:
            audit = doas
        params = {'dsn': dsn, "statement": statement, 'doas': doas, 'audit': audit, 'engine': engine,
                'use_cache': use_cache, 'cache_expire': cache_expire, 'debug': debug, 'sync': sync,
                'timeout': timeout, 'properties': properties, 'sdkScene': self.sdk_scene.name}

        otherParam = {}
        if properties:
            for key,value in properties.items():
                if not params.get(key):
                    otherParam[key]=value
        params.update(otherParam)

        res = requests.post(api, data=params, headers={'Authorization': self.token}, timeout=timeout)

        raise_exception(res)
        return res.json()["data"]

    def open_session(self, timeout=20):
        self._login(timeout=timeout)

    def close_session(self):
        if hasattr(self, "token"):
            self._logout()

    @need_login
    @renew_token(exceptions=(TalosException,))
    def download(self, qid, timeout=20):
        api = "{0}/api/v1/queries/download".format(self.endpoint)
        res = requests.get(api, params={'qid': qid}, stream=True, headers={'Authorization': self.token}, allow_redirects=True, timeout=timeout)
        raise_exception_for_download(res)
        for line in res.iter_lines(decode_unicode=True, delimiter='\n', chunk_size=8192):
            if line:
                yield line.split('\x01')

    @need_login
    @renew_token(exceptions=(TalosException,))
    def download_with_stream(self, qid, timeout=20):
        api = "{0}/api/v1/queries/download".format(self.endpoint)
        res = requests.get(api, params={'qid': qid}, stream=True, headers={'Authorization': self.token}, allow_redirects=True, timeout=timeout)
        raise_exception_for_download(res)
        for chunk in res.iter_content(chunk_size=8192):
            if chunk:
                yield chunk
    
    @need_login
    @renew_token(exceptions=(TalosException,))
    def download_to_file(self, qid, file_path, delimiter=None, timeout=20):
        api = "{0}/api/v1/queries/download".format(self.endpoint)
        res = requests.get(api, params={'qid': qid}, stream=True, headers={'Authorization': self.token}, allow_redirects=True, timeout=timeout)
        raise_exception_for_download(res)
        with open(file_path, 'wb') as f:
            for chunk in res.iter_content(chunk_size=8192):
                if chunk:
                    if delimiter:
                        f.write(chunk.replace(b'\x01', delimiter))
                    else:
                        f.write(chunk)

    @need_login
    @renew_token(exceptions=(TalosException,))
    def fetch_result(self, qid, offset, length, timeout=20):
        api = "{0}/api/v1/queries/result".format(self.endpoint)
        res = requests.get(api,
                           params={"qid": qid, "offset": offset, "length": length},
                           headers={'Authorization': self.token},
                           allow_redirects=True,
                           timeout=timeout
                           )
        raise_exception(res)
        return res.json()["data"]

    @need_login
    @renew_token(exceptions=(TalosException,))
    def engine_log(self, qid, timeout=20):
        api = "{0}/api/v1/enginelog".format(self.endpoint)
        res = requests.get(api,
                           params={"qid": qid},
                           headers={'Authorization': self.token},
                           allow_redirects=True,
                           timeout=timeout)
        raise_exception(res)
        return res.json()["data"]

    def fetch_result1(self, url, timeout=20):
        """

        :param url: 重定向之后的URL
        :return:
        """
        res = requests.get(url, auth=self.auth, timeout=timeout)

        if res.status_code != 200:
            raise TalosException(res.content)
        else:
            if res.json().get("error"):
                raise TalosException(res.json().get("error").get("msg"))
        return res.json()["data"]

    def fetch_one(self, qid):
        return self.fetch_result(qid, offset=0, length=1)

    def fetch_many(self, qid, num):
        return self.fetch_result(qid, offset=0, length=num)

    def fetch_all(self, qid):
        return self.fetch_result(qid, offset=0, length=sys.maxsize)


class AsyncTalosClient(Talos):
    def submit(self, statement, doas=None, audit=None, engine="onesql", use_cache=True, cache_expire=3600, debug=False,
               properties=None, dsn="hive", timeout=20):
        qid = self._submit(dsn, statement, doas, audit, engine=engine, use_cache=use_cache,
                           cache_expire=cache_expire, debug=debug, sync=False, properties=properties, timeout=timeout)
        return qid

    @need_login
    @renew_token(exceptions=(TalosException,))
    def get_query_info(self, qid, timeout=20):
        api = "{0}/api/v1/queries".format(self.endpoint)
        res = requests.get(api, params={"qid": qid}, headers={'Authorization': self.token}, timeout=timeout)
        raise_exception(res)
        return res.json().get('data')

    @need_login
    @renew_token(exceptions=(TalosException,))
    def cancel(self, qid, timeout=20):
        api = "{0}/api/v1/queries".format(self.endpoint)
        res = requests.delete(api, params={"qid": qid}, headers={'Authorization': self.token}, timeout=timeout)
        raise_exception(res)
        print(res.content)
        logger.info(res.json().get("message"))
        return True
